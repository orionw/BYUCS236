#include <iostream>
#include <string>
#include <list>
#include <fstream>
#include <vector>
#include "Lexer.h"
using namespace std;

int main(int argc, char *argv[]) {
	// Input file and call Lexer on it;
	Lexer* parse = new Lexer(argv[1]);
	delete parse;
	return 0;
}




