#pragma once
#include <iostream>
#include <string>
#include <list>
#include <fstream>
#include <vector>
#include <set>
#include "Lexer.h"
#include "Utilities.h"
#include "Operator.h"
#include "Parameter.h"
#include "Utilities.h"
using namespace std;


